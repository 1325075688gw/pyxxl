from .client import GConfClient

__all__ = ["GConfClient"]
