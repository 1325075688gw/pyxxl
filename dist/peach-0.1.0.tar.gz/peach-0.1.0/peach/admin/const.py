SESSION_USER_KEY = "user_id"

ACTION = {"POST": 1, "PUT": 2, "DELETE": 3, "GET": 4}


DEFAULT_PASSWORD = "123!@#qwe"
