# -*- coding: utf-8 -*-

"""
   commands
~~~~~~~~~~~~~~

此module存放自定义的command.
可以供python manage.py <command> 调用

"""
